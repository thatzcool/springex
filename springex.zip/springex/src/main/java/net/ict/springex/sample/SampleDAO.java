package net.ict.springex.sample;

public interface SampleDAO {
}
